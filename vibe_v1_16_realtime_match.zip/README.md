# Vibe — v1.16 synchronized match client

Flutter client for the Vibe Supabase backend.

## Added in v1.16
- Quiz Clash creates a server-backed round for each question.
- Player answers are submitted through the protected `submit_game_answer` RPC.
- Quiz clients listen for opponent answer events with Supabase Realtime.
- Match completion calls the protected `finish_game_match` RPC.
- Existing real authentication, social, matchmaking, voice-match foundation, effects and leaderboards remain.

## Build
Requires Flutter SDK and Android/iOS toolchains.

```bash
flutter pub get
flutter build apk --release
```

This ZIP is source code, not a prebuilt APK. WebRTC audio, production media scanning, push credentials, billing, moderation operations, anti-cheat hardening, store accounts and release testing are still required for public launch.
