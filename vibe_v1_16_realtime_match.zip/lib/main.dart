import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';
import 'dart:async';

const supabaseUrl = 'https://bowpakxmbhqaxldlsbsc.supabase.co';
const supabaseKey = 'sb_publishable_zL7b64sHQnW7MiTx6-kQQg_DjUAOZnt';
final db = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: supabaseKey);
  runApp(const VibeApp());
}

class VibeApp extends StatelessWidget {
  const VibeApp({super.key});
  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF08090D);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Vibe',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF12141B),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
        cardTheme: CardThemeData(color: const Color(0xFF11131A), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: db.auth.onAuthStateChange,
    builder: (_, __) => db.auth.currentSession == null ? const LoginPage() : const HomePage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(), pass = TextEditingController(), name = TextEditingController();
  bool signup = false, busy = false;
  Future<void> submit() async {
    if (email.text.trim().isEmpty || pass.text.length < 6 || (signup && name.text.trim().isEmpty)) return;
    setState(() => busy = true);
    try {
      if (signup) {
        await db.auth.signUp(email: email.text.trim(), password: pass.text, data: {'display_name': name.text.trim()});
      } else {
        await db.auth.signInWithPassword(email: email.text.trim(), password: pass.text);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(28), child: Column(children: [
      Container(width: 92, height: 92, decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: const LinearGradient(colors: [Color(0xFF8B5CF6), Color(0xFF14B8A6)])), child: const Icon(Icons.all_inclusive_rounded, size: 52)),
      const SizedBox(height: 22),
      const Text('VIBE', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: 8)),
      const SizedBox(height: 5), const Text('People. Moments. Play.', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 38),
      if (signup) ...[TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Display name')), const SizedBox(height: 12)],
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email')), const SizedBox(height: 12),
      TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Password')), const SizedBox(height: 18),
      SizedBox(width: double.infinity, height: 54, child: FilledButton(onPressed: busy ? null : submit, child: busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Text(signup ? 'Create account' : 'Log in'))),
      TextButton(onPressed: () => setState(() => signup = !signup), child: Text(signup ? 'Already have an account? Log in' : 'New here? Create an account')),
    ]))),
  );
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  int tab = 0;
  final pages = const [DiscoverPage(), FeedPage(), GamesPage(), VoiceMatchPage(), ProfilePage()];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('VIBE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 3)), actions: [
      StreamBuilder<List<Map<String,dynamic>>>(stream: db.from('notifications').stream(primaryKey: ['id']).eq('user_id', db.auth.currentUser?.id ?? '').order('created_at', ascending: false), builder: (_, snap) { final unread = snap.data?.where((n) => n['is_read'] != true).length ?? 0; return IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage())), icon: Stack(clipBehavior: Clip.none, children: [const Icon(Icons.notifications_none), if (unread > 0) Positioned(right: -2, top: -4, child: Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2), decoration: BoxDecoration(color: const Color(0xFF8B5CF6), borderRadius: BorderRadius.circular(10)), child: Text(unread > 99 ? '99+' : '$unread', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold))))])); }),
      IconButton(icon: const Icon(Icons.chat_bubble_outline), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatsPage()))), const SizedBox(width: 8)]),
    body: pages[tab],
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
      NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Discover'),
      NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Vibes'),
      NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Play'),
      NavigationDestination(icon: Icon(Icons.mic_none), selectedIcon: Icon(Icons.mic), label: 'Voice'),
      NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
    ]),
  );
}

class VoiceMatchPage extends StatefulWidget { const VoiceMatchPage({super.key}); @override State<VoiceMatchPage> createState()=>_VoiceMatchPageState(); }
class _VoiceMatchPageState extends State<VoiceMatchPage> {
  String? matchId; String status='idle'; Timer? timer; Map<String,dynamic>? row;
  @override void dispose(){timer?.cancel(); super.dispose();}
  Future<void> find() async {
    try { final id=await db.rpc('join_voice_match'); matchId=id.toString(); await check(); timer=Timer.periodic(const Duration(seconds:2),(_)=>check()); }
    catch(e){if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Voice matching unavailable: $e')));}
  }
  Future<void> check() async {
    if(matchId==null)return;
    try { final r=await db.from('voice_matches').select('id,status,partner_id').eq('id',matchId!).maybeSingle(); if(r==null)return; if(mounted)setState(()=>row=r); if(r['status']=='matched'){timer?.cancel(); if(mounted)setState(()=>status='matched');} else if(mounted)setState(()=>status='searching'); }
    catch(_){ }
  }
  Future<void> cancel() async { if(matchId!=null){try{await db.rpc('cancel_voice_match',params:{'p_match_id':matchId});}catch(_){}} timer?.cancel(); if(mounted)setState((){status='idle';matchId=null;row=null;}); }
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const SizedBox(height:24), const Text('Voice',style:TextStyle(fontSize:32,fontWeight:FontWeight.w900)), const SizedBox(height:8),
    Text(status=='searching'?'Finding someone to talk to…':status=='matched'?'You found a Vibe.':'Meet someone random and start a conversation.',style:const TextStyle(color:Colors.white60,fontSize:16)),
    const Spacer(),
    Center(child:Container(width:150,height:150,decoration:BoxDecoration(shape:BoxShape.circle,gradient:LinearGradient(colors:[Color(0xFF8B5CF6),Color(0xFF14B8A6)]),boxShadow:[BoxShadow(color:Color(0x668B5CF6),blurRadius:40)]),child:Icon(status=='matched'?Icons.check:Icons.mic,size:70))),
    const SizedBox(height:28), Center(child:Text(status=='matched'?'MATCH FOUND':'RANDOM VOICE MATCH',style:const TextStyle(fontWeight:FontWeight.w800,letterSpacing:2))), const SizedBox(height:12),
    if(status=='matched') const Center(child:Text('Voice session is ready. WebRTC call connection comes next.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white54))),
    const Spacer(),
    SizedBox(height:54,child:FilledButton.icon(onPressed:status=='idle'?find:status=='searching'?cancel:cancel,icon:Icon(status=='idle'?Icons.search:Icons.close),label:Text(status=='idle'?'Find someone':status=='searching'?'Cancel search':'End match'))),
    const SizedBox(height:12), const Text('Your microphone is not activated until you start a voice session.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white38,fontSize:12)),
  ]))));
}

class DiscoverPage extends StatefulWidget { const DiscoverPage({super.key}); @override State<DiscoverPage> createState() => _DiscoverPageState(); }
class _DiscoverPageState extends State<DiscoverPage> {
  Future<List<Map<String,dynamic>>> load() async {
    final me = db.auth.currentUser!.id;
    final rows = await db.rpc('discover_profiles', params: {'p_interests': [], 'p_limit': 40});
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<void> connect(Map<String,dynamic> user) async {
    try {
      await db.from('friendships').upsert({'requester_id': db.auth.currentUser!.id, 'addressee_id': user['id'], 'status': 'pending'}, onConflict: 'requester_id,addressee_id');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Connection request sent')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }
  Future<void> requests() async {
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const FriendRequestsPage()));
    if (mounted) setState(() {});
  }
  Future<void> chat(Map<String,dynamic> user) async {
    try {
      final r = await db.rpc('start_direct_conversation', params: {'other_user_id': user['id']});
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(conversationId: r.toString(), title: user['display_name'] ?? 'Vibe user')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }
  @override Widget build(BuildContext context) => FutureBuilder<List<Map<String,dynamic>>>(
    future: load(), builder: (context, s) => RefreshIndicator(onRefresh: () async => setState(() {}), child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 30), children: [
      Row(children: [const Expanded(child: Text('Find your people', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))), IconButton(onPressed: requests, icon: const Icon(Icons.person_add_alt_1))]), const SizedBox(height: 5), const Text('Real people. Better conversations.', style: TextStyle(color: Colors.white54)), const SizedBox(height: 14), Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), child: Row(children: [const Icon(Icons.search, color: Colors.white54), const SizedBox(width: 8), const Expanded(child: Text('Discover people by vibe, interests or profile', style: TextStyle(color: Colors.white54))), IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Smart discovery filters are coming next.')),), icon: const Icon(Icons.tune))]))), const SizedBox(height: 14),
      if (s.connectionState == ConnectionState.waiting) const Center(child: Padding(padding: EdgeInsets.all(35), child: CircularProgressIndicator())),
      ...?s.data?.map((u) => Card(margin: const EdgeInsets.only(bottom: 12), child: InkWell(borderRadius: BorderRadius.circular(22), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewPage(user: Map<String,dynamic>.from(u)))), child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [
        CircleAvatar(radius: 26, backgroundImage: u['avatar_url'] != null ? NetworkImage(u['avatar_url']) : null, child: u['avatar_url'] == null ? Text((u['display_name'] ?? 'V')[0].toUpperCase()) : null), const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Flexible(child: Text(u['display_name'] ?? 'Vibe user', style: const TextStyle(fontWeight: FontWeight.bold))), if (u['is_human_verified'] == true) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.verified, size: 16))]), Text('@${u['username'] ?? ''}', style: const TextStyle(color: Colors.white54)), if ((u['bio'] ?? '').toString().isNotEmpty) Text(u['bio'], maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70))])),
        PopupMenuButton<String>(onSelected: (v) { if (v == 'chat') chat(u); else if (v == 'connect') connect(u); else Navigator.push(context, MaterialPageRoute(builder: (_) => SafetyActionPage(userId: u['id'], userName: u['display_name'] ?? 'Vibe user'))); }, itemBuilder: (_) => const [PopupMenuItem(value: 'chat', child: Text('Message')), PopupMenuItem(value: 'connect', child: Text('Connect')), PopupMenuItem(value: 'safety', child: Text('Report / Block'))]),
      ])))),
      if (s.hasData && s.data!.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No one new yet. Invite a friend to Vibe.'))),
    ])),
  );
}


class FriendRequestsPage extends StatefulWidget { const FriendRequestsPage({super.key}); @override State<FriendRequestsPage> createState()=>_FriendRequestsPageState(); }
class _FriendRequestsPageState extends State<FriendRequestsPage> {
  bool busy=false;
  Future<List<Map<String,dynamic>>> load() async {
    final me=db.auth.currentUser!.id;
    final rows=await db.from('friendships').select('id,requester_id,status,created_at').eq('addressee_id',me).eq('status','pending').order('created_at',ascending:false);
    final out=<Map<String,dynamic>>[];
    for(final r in rows){ final p=await db.from('profiles').select('id,display_name,username,avatar_url,is_human_verified').eq('id',r['requester_id']).maybeSingle(); if(p!=null) out.add({...Map<String,dynamic>.from(p),'friendship_id':r['id']}); }
    return out;
  }
  Future<void> act(String id,String status) async { setState(()=>busy=true); try { await db.from('friendships').update({'status':status,'updated_at':DateTime.now().toIso8601String()}).eq('id',id).eq('addressee_id',db.auth.currentUser!.id); if(mounted)setState((){}); } catch(e){ if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not update request: $e'))); } finally{if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Friend requests')),body:FutureBuilder<List<Map<String,dynamic>>>(future:load(),builder:(_,s)=>ListView(padding:const EdgeInsets.all(18),children:[if(!s.hasData)const Center(child:CircularProgressIndicator()),...?s.data?.map((u)=>Card(child:ListTile(leading:CircleAvatar(child:Text((u['display_name']??'V')[0].toString().toUpperCase())),title:Text(u['display_name']??'Vibe user'),subtitle:Text('@${u['username']??''}'),trailing:SizedBox(width:130,child:Row(mainAxisAlignment:MainAxisAlignment.end,children:[IconButton(onPressed:busy?null:()=>act(u['friendship_id'],'accepted'),icon:const Icon(Icons.check_circle_outline)),IconButton(onPressed:busy?null:()=>act(u['friendship_id'],'declined'),icon:const Icon(Icons.close))])))),if(s.hasData&&s.data!.isEmpty)const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('No pending requests right now.')))]));
}

class FeedPage extends StatefulWidget { const FeedPage({super.key}); @override State<FeedPage> createState() => _FeedPageState(); }
class _FeedPageState extends State<FeedPage> {
  final picker = ImagePicker();
  bool busy = false;
  Future<void> createPost() async {
    final c = TextEditingController(); XFile? picked;
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (ctx,setLocal) => AlertDialog(
      title: const Text('Share a vibe'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: c, maxLines: 4, decoration: const InputDecoration(hintText: 'What are you thinking?')),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () async { final x=await picker.pickImage(source: ImageSource.gallery, imageQuality: 88, maxWidth: 1800); if(x!=null)setLocal(()=>picked=x); }, icon: const Icon(Icons.photo_outlined), label: Text(picked==null?'Add photo':'Photo selected')),
        if(picked!=null) Padding(padding: const EdgeInsets.only(top:8), child: Text(picked!.name, maxLines:1, overflow:TextOverflow.ellipsis, style:const TextStyle(color:Colors.white54)))
      ]),
      actions: [TextButton(onPressed: ()=>Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: busy ? null : () async {
        if(c.text.trim().isEmpty && picked==null) return;
        setLocal(()=>busy=true);
        try {
          String? mediaUrl;
          if(picked!=null){
            final bytes=await picked!.readAsBytes(); final path='${db.auth.currentUser!.id}/${DateTime.now().microsecondsSinceEpoch}_${picked!.name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'),'_')}';
            await db.storage.from('post-media').uploadBinary(path, bytes, fileOptions: const FileOptions(upsert:false, contentType:'image/jpeg'));
            mediaUrl=db.storage.from('post-media').getPublicUrl(path);
          }
          await db.from('posts').insert({'author_id':db.auth.currentUser!.id,'caption':c.text.trim(),'media_url':mediaUrl});
          if(ctx.mounted) Navigator.pop(ctx);
        } catch(e){ if(ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content:Text('Could not share: $e'))); }
        finally{ if(mounted)setState(()=>busy=false); }
      }, child: busy ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Text('Post'))]
    )));
  }
  Future<void> like(String postId) async { try { await db.rpc('toggle_post_like', params: {'p_post_id': postId}); } catch (_) {} }
  Future<void> comment(String postId) async {
    final c=TextEditingController(); await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Comment'),content:TextField(controller:c,maxLines:3,decoration:const InputDecoration(hintText:'Say something...')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()async{if(c.text.trim().isNotEmpty)await db.from('post_comments').insert({'post_id':postId,'user_id':db.auth.currentUser!.id,'body':c.text.trim()});if(context.mounted)Navigator.pop(context);},child:const Text('Send'))]));
  }
  @override Widget build(BuildContext context) => Scaffold(
    floatingActionButton: FloatingActionButton.extended(onPressed: createPost, icon: const Icon(Icons.add), label: const Text('Share')),
    body: StreamBuilder<List<Map<String,dynamic>>>(stream: db.from('posts').stream(primaryKey: ['id']).order('created_at', ascending:false), builder: (_,s) => ListView(padding:const EdgeInsets.fromLTRB(18,8,18,90),children:[
      const Text('Vibes',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const Text('Your corner of the internet.',style:TextStyle(color:Colors.white54)),const SizedBox(height:18),
      if(!s.hasData)const Center(child:CircularProgressIndicator()),
      ...?s.data?.map((p)=>Card(margin:const EdgeInsets.only(bottom:14),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        if((p['media_url']??'').toString().isNotEmpty) ClipRRect(borderRadius:BorderRadius.circular(16),child:AspectRatio(aspectRatio:4/3,child:Image.network(p['media_url'],fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Center(child:Icon(Icons.broken_image_outlined,size:40))))),
        if((p['caption']??'').toString().isNotEmpty) Padding(padding:const EdgeInsets.only(top:12),child:Text(p['caption'],style:const TextStyle(fontSize:18,height:1.35))),
        const SizedBox(height:6),Row(children:[IconButton(onPressed:()=>like(p['id']),icon:const Icon(Icons.favorite_border)),IconButton(onPressed:()=>comment(p['id']),icon:const Icon(Icons.chat_bubble_outline)),const Spacer(),Text(_time(p['created_at']),style:const TextStyle(color:Colors.white38,fontSize:12))])
      ])))),
    ])),
  );
  String _time(dynamic raw){if(raw==null)return '';final d=DateTime.tryParse(raw.toString());if(d==null)return '';final m=DateTime.now().difference(d).inMinutes;return m<1?'now':m<60?'${m}m':m<1440?'${m~/60}h':'${m~/1440}d';}
}
class ChatsPage extends StatefulWidget { const ChatsPage({super.key}); @override State<ChatsPage> createState() => _ChatsPageState(); }
class _ChatsPageState extends State<ChatsPage> {
  Future<List<Map<String,dynamic>>> load() async {
    final me = db.auth.currentUser!.id;
    final rows = await db.from('conversation_members').select('conversation_id, user_id').eq('user_id', me);
    final result = <Map<String,dynamic>>[];
    for (final row in rows) {
      final members = await db.from('conversation_members').select('user_id').eq('conversation_id', row['conversation_id']);
      final other = members.cast<Map<String,dynamic>>().firstWhere((m) => m['user_id'] != me, orElse: () => {});
      if (other.isEmpty) continue;
      final p = await db.from('profiles').select('id,display_name,username,avatar_url').eq('id', other['user_id']).maybeSingle();
      if (p != null) result.add({...Map<String,dynamic>.from(p), 'conversation_id': row['conversation_id']});
    }
    return result;
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Messages')), body: FutureBuilder<List<Map<String,dynamic>>>(future: load(), builder: (_, s) => ListView(padding: const EdgeInsets.all(18), children: [if (!s.hasData) const Center(child: CircularProgressIndicator()), ...?s.data?.map((u) => Card(child: ListTile(leading: CircleAvatar(child: Text((u['display_name'] ?? 'V')[0])), title: Text(u['display_name'] ?? 'Vibe user'), subtitle: Text('@${u['username'] ?? ''}'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(conversationId: u['conversation_id'].toString(), title: u['display_name'] ?? 'Vibe user')))))), if (s.hasData && s.data!.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Text('No conversations yet. Find someone and start a chat.'))]));
}

class ChatPage extends StatefulWidget { final String conversationId, title; const ChatPage({super.key, required this.conversationId, required this.title}); @override State<ChatPage> createState() => _ChatPageState(); }
class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  Future<void> send() async { final text = input.text.trim(); if (text.isEmpty) return; input.clear(); await db.from('messages').insert({'conversation_id': widget.conversationId, 'sender_id': db.auth.currentUser!.id, 'body': text}); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.title)), body: Column(children: [Expanded(child: StreamBuilder<List<Map<String,dynamic>>>(stream: db.from('messages').stream(primaryKey: ['id']).eq('conversation_id', widget.conversationId).order('created_at'), builder: (_, s) => ListView(padding: const EdgeInsets.all(16), children: [...?s.data?.map((m) { final mine = m['sender_id'] == db.auth.currentUser!.id; return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11), constraints: const BoxConstraints(maxWidth: 300), decoration: BoxDecoration(color: mine ? const Color(0xFF7048D8) : const Color(0xFF191C25), borderRadius: BorderRadius.circular(18)), child: Text(m['body'] ?? '')); })])))), SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(12, 6, 12, 10), child: Row(children: [Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'Message...'))), const SizedBox(width: 8), IconButton.filled(onPressed: send, icon: const Icon(Icons.send))])))]));
}

class GamesPage extends StatelessWidget { const GamesPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 30), children: [
    const Text('Play', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
    const Text('Compete, connect, climb.', style: TextStyle(color: Colors.white54)), const SizedBox(height: 20),
    _game(context, 'Quiz Clash', '🧠', 'Find a real player and battle 5 questions.', 'quiz_clash'),
    _game(context, 'Reaction Rush', '⚡', 'Match with a real player and test your reflexes.', 'reaction_rush'),
    _game(context, 'Meme Battle', '😂', 'Create. Vote. Climb the board.'), const SizedBox(height: 18),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Arena', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 6),
      const Text('Weekly • Monthly • All-time', style: TextStyle(color: Colors.white54)), const SizedBox(height: 14),
      FilledButton.tonal(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LeaderboardPage())), child: const Text('View leaderboard'))]))]);
  Widget _game(BuildContext c, String name, String emoji, String desc, [String? gameType]) => Card(margin: const EdgeInsets.only(bottom: 12), child: ListTile(contentPadding: const EdgeInsets.all(14), leading: Text(emoji, style: const TextStyle(fontSize: 34)), title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(desc), trailing: const Icon(Icons.arrow_forward_ios, size: 16), onTap: gameType == null ? null : () => Navigator.push(c, MaterialPageRoute(builder: (_) => MatchmakingPage(gameType: gameType, title: name))));
}

class MatchmakingPage extends StatefulWidget { final String gameType, title; const MatchmakingPage({super.key, required this.gameType, required this.title}); @override State<MatchmakingPage> createState()=>_MatchmakingPageState(); }
class _MatchmakingPageState extends State<MatchmakingPage>{
  bool searching=false; String? queueId; String? sessionId; RealtimeChannel? channel;
  Future<void> search(){ return _start(); }
  Future<void> _start() async { setState(()=>searching=true); try { final id=await db.rpc('join_game_queue',params:{'p_game_type':widget.gameType}); final sid=id.toString(); final session=await db.from('game_sessions').select('id,status').eq('id',sid).maybeSingle(); if(session!=null){_openGame(sid);return;} queueId=sid; channel=db.channel('match_${db.auth.currentUser!.id}_${widget.gameType}')..onPostgresChanges(event:PostgresChangeEvent.all,schema:'public',table:'game_sessions',callback:(payload) async { final row=payload.newRecord; if(row['player_one']==db.auth.currentUser!.id||row['player_two']==db.auth.currentUser!.id){final id=row['id']?.toString();if(id!=null)_openGame(id);}})..subscribe(); } catch(e){if(mounted){setState(()=>searching=false);ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Matchmaking unavailable: $e')));}} }
  void _openGame(String id){channel?.unsubscribe(); if(!mounted)return; setState(()=>sessionId=id); Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>widget.gameType=='quiz_clash'?QuizClashPage(sessionId:id):ReactionRushPage(sessionId:id)));}
  Future<void> cancel() async { if(queueId!=null){await db.from('game_matchmaking_queue').delete().eq('id',queueId!);} channel?.unsubscribe(); if(mounted)Navigator.pop(context); }
  @override void dispose(){channel?.unsubscribe();super.dispose();}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.title)),body:Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.people_alt_outlined,size:64),const SizedBox(height:18),Text(searching?'Finding a real player…':'Ready to find a real player?',style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800),textAlign:TextAlign.center),const SizedBox(height:10),const Text('No bots. When another player joins, the game session starts.',style:TextStyle(color:Colors.white54),textAlign:TextAlign.center),const SizedBox(height:26),if(searching)const CircularProgressIndicator(),if(!searching)FilledButton(onPressed:search,child:const Text('Find opponent')),if(searching)TextButton(onPressed:cancel,child:const Text('Cancel'))]))));
}

class LeaderboardPage extends StatelessWidget { const LeaderboardPage({super.key});
  @override Widget build(BuildContext context) => DefaultTabController(length: 3, child: Scaffold(appBar: AppBar(title: const Text('Leaderboard'), bottom: const TabBar(tabs: [Tab(text: 'Weekly'), Tab(text: 'Monthly'), Tab(text: 'All-time')])), body: const TabBarView(children: [LeaderboardList(view: 'leaderboard_weekly'), LeaderboardList(view: 'leaderboard_monthly'), LeaderboardList(view: 'leaderboard_all_time')]));
}
class LeaderboardList extends StatelessWidget { final String view; const LeaderboardList({super.key, required this.view});
  @override Widget build(BuildContext context) => FutureBuilder<List<Map<String,dynamic>>>(future: db.from(view).select().order('xp', ascending: false).limit(50), builder: (_, s) => ListView(padding: const EdgeInsets.all(18), children: [if (!s.hasData) const Center(child: CircularProgressIndicator()), ...?s.data?.asMap().entries.map((e) { final u=e.value; return Card(child: ListTile(leading: CircleAvatar(child: Text('${e.key+1}')), title: Text(u['display_name'] ?? u['username'] ?? 'Player'), trailing: Text('${u['xp'] ?? 0} XP', style: const TextStyle(fontWeight: FontWeight.bold))); }), if (s.hasData && s.data!.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Text('Leaderboard will light up when players start earning XP.'))]));
}

class NotificationsPage extends StatefulWidget { const NotificationsPage({super.key}); @override State<NotificationsPage> createState()=>_NotificationsPageState(); }
class _NotificationsPageState extends State<NotificationsPage>{
  Future<List<Map<String,dynamic>>> load() async {
    final me=db.auth.currentUser!.id;
    final rows=await db.from('notifications').select('id,actor_id,kind,type,title,body,entity_id,created_at,read_at').eq('user_id',me).order('created_at',ascending:false).limit(50);
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<void> markRead(String id) async { await db.from('notifications').update({'read_at':DateTime.now().toIso8601String()}).eq('id',id).eq('user_id',db.auth.currentUser!.id); if(mounted)setState((){}); }
  IconData iconFor(String? kind){ switch(kind){case 'friend_request':return Icons.person_add_alt_1;case 'message':return Icons.chat_bubble_outline;default:return Icons.notifications_none;} }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Notifications')),body:FutureBuilder<List<Map<String,dynamic>>>(future:load(),builder:(_,s){
    final rows=s.data??const <Map<String,dynamic>>[];
    return ListView(padding:const EdgeInsets.all(18),children:[
      const Card(child:ListTile(leading:Icon(Icons.shield_outlined),title:Text('Vibe safety reminder'),subtitle:Text('Block or report serious abuse whenever needed.'))),
      if(s.connectionState==ConnectionState.waiting)const Padding(padding:EdgeInsets.all(30),child:Center(child:CircularProgressIndicator())),
      ...rows.map((n)=>Card(color:n['read_at']==null?const Color(0xFF181B26):null,child:ListTile(leading:CircleAvatar(child:Icon(iconFor(n['kind']??n['type']))),title:Text(n['title']??'Notification'),subtitle:Text(n['body']??''),trailing:n['read_at']==null?const Icon(Icons.circle,size:9):null,onTap:()=>n['read_at']==null?markRead(n['id'].toString()):null))),
      if(s.hasData&&rows.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Text('You’re all caught up.'))
    ]);
  }));
}

class ProfileViewPage extends StatelessWidget {
  final Map<String,dynamic> user;
  const ProfileViewPage({super.key, required this.user});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(user['display_name'] ?? 'Profile')), body: ListView(padding: const EdgeInsets.all(22), children: [
    Center(child: CircleAvatar(radius: 52, backgroundImage: user['avatar_url'] != null ? NetworkImage(user['avatar_url']) : null, child: user['avatar_url'] == null ? Text((user['display_name'] ?? 'V')[0].toUpperCase(), style: const TextStyle(fontSize: 32)) : null)),
    const SizedBox(height: 14), Center(child: Text(user['display_name'] ?? 'Vibe user', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900))),
    Center(child: Text('@${user['username'] ?? ''}', style: const TextStyle(color: Colors.white54))),
    if ((user['bio'] ?? '').toString().isNotEmpty) ...[const SizedBox(height: 18), Text(user['bio'], textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))],
    if ((user['interests'] as List?)?.isNotEmpty ?? false) ...[const SizedBox(height: 20), Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: (user['interests'] as List).map((x)=>Chip(label: Text(x.toString()))).toList())],
    const SizedBox(height: 24),
    FilledButton.icon(onPressed: () async { try { final r=await db.rpc('start_direct_conversation', params:{'other_user_id':user['id']}); if(context.mounted) Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatPage(conversationId:r.toString(),title:user['display_name']??'Vibe user'))); } catch(e) { if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not start chat: $e'))); } }, icon: const Icon(Icons.chat_bubble_outline), label: const Text('Message')),
  ]);
}

class ProfilePage extends StatefulWidget { const ProfilePage({super.key}); @override State<ProfilePage> createState() => _ProfilePageState(); }
class _ProfilePageState extends State<ProfilePage> {
  Map<String,dynamic>? p; final interests=TextEditingController(); final display=TextEditingController(), username=TextEditingController(), bio=TextEditingController();
  final picker=ImagePicker(); bool saving=false, uploading=false;
  @override void initState(){super.initState(); load();}
  Future<void> load() async { try { final r=await db.from('profiles').select().eq('id',db.auth.currentUser!.id).single(); display.text=r['display_name']??''; username.text=r['username']??''; bio.text=r['bio']??''; interests.text=((r['interests'] as List?) ?? []).join(', '); if(mounted)setState(()=>p=Map<String,dynamic>.from(r)); } catch(_){if(mounted)setState(()=>p={});} }
  Future<void> avatar() async {
    final x=await picker.pickImage(source:ImageSource.gallery,imageQuality:90,maxWidth:1200); if(x==null)return;
    setState(()=>uploading=true); try { final bytes=await x.readAsBytes(); final path='${db.auth.currentUser!.id}/avatar_${DateTime.now().millisecondsSinceEpoch}.jpg'; await db.storage.from('post-media').uploadBinary(path,bytes,fileOptions:const FileOptions(upsert:false,contentType:'image/jpeg')); final url=db.storage.from('post-media').getPublicUrl(path); await db.from('profiles').update({'avatar_url':url}).eq('id',db.auth.currentUser!.id); await load(); if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Profile photo updated'))); } catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Photo upload failed: $e')));} finally{if(mounted)setState(()=>uploading=false);}
  }
  Future<void> save() async { setState(()=>saving=true); try { await db.from('profiles').upsert({'id':db.auth.currentUser!.id,'display_name':display.text.trim(),'username':username.text.trim(),'bio':bio.text.trim(),'interests':interests.text.split(',').map((e)=>e.trim().toLowerCase()).where((e)=>e.isNotEmpty).take(12).toList()}); await load(); if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Profile updated'))); } catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not save: $e')));} finally{if(mounted)setState(()=>saving=false);} }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 30), children: [
    const Text('Your Vibe',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:20),
    if(p==null)const Center(child:CircularProgressIndicator()) else ...[
      Center(child:Stack(alignment:Alignment.bottomRight,children:[CircleAvatar(radius:52,backgroundImage:p!['avatar_url']!=null?NetworkImage(p!['avatar_url']):null,child:p!['avatar_url']==null?Text((display.text.isEmpty?'V':display.text)[0].toUpperCase(),style:const TextStyle(fontSize:32,fontWeight:FontWeight.bold)):null),Container(decoration:const BoxDecoration(shape:BoxShape.circle),child:IconButton.filled(onPressed:uploading?null:avatar,icon:uploading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.camera_alt,size:18)))])),
      const SizedBox(height:10),Center(child:Text('@${username.text.isEmpty?'your_username':username.text}',style:const TextStyle(color:Colors.white54))),const SizedBox(height:22),
      TextField(controller:display,decoration:const InputDecoration(labelText:'Display name')),const SizedBox(height:12),TextField(controller:username,decoration:const InputDecoration(labelText:'Username')),const SizedBox(height:12),TextField(controller:bio,maxLines:3,decoration:const InputDecoration(labelText:'Bio',hintText:'A little about you...')),const SizedBox(height:12),TextField(controller:interests,decoration:const InputDecoration(labelText:'Interests',hintText:'gaming, anime, finance, music')),const SizedBox(height:16),
      SizedBox(height:52,width:double.infinity,child:FilledButton(onPressed:saving?null:save,child:saving?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Text('Save profile'))),const SizedBox(height:18),
      const Text('Your space',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),
      OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ChatsPage())),icon:const Icon(Icons.chat_bubble_outline),label:const Text('Messages')),
      OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FriendRequestsPage())),icon:const Icon(Icons.people_outline),label:const Text('Friend requests')),
      OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const NotificationsPage())),icon:const Icon(Icons.notifications_none),label:const Text('Notifications')),
      OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const EffectsPage())),icon:const Icon(Icons.auto_awesome),label:const Text('Vibe Effects')),
      OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SafetyCenterPage())),icon:const Icon(Icons.shield_outlined),label:const Text('Safety Center')),
      const SizedBox(height:10),OutlinedButton.icon(onPressed:()=>db.auth.signOut(),icon:const Icon(Icons.logout),label:const Text('Log out')),
      const SizedBox(height:24),const Text('Safety & privacy',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:7),const Text('You control who can find and contact you. Block or report serious abuse whenever needed.',style:TextStyle(color:Colors.white54)),
    ]]);
}

class EffectsPage extends StatelessWidget { const EffectsPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar:AppBar(title:const Text('Vibe Effects')),body:FutureBuilder<List<Map<String,dynamic>>>(future:db.from('effect_catalog').select().eq('active',true).order('is_premium').order('name'),builder:(_,s)=>ListView(padding:const EdgeInsets.all(18),children:[const Text('Make it yours.',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const Text('Free effects first. Premium is optional.',style:TextStyle(color:Colors.white54)),const SizedBox(height:18),if(!s.hasData)const Center(child:CircularProgressIndicator()),...?s.data?.map((e)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(e['is_premium']==true?Icons.workspace_premium:Icons.auto_awesome)),title:Text(e['name']),subtitle:Text(e['description']),trailing:e['is_premium']==true?const Text('VIBE+',style:TextStyle(fontWeight:FontWeight.bold)):const Text('FREE'))))]));
}



class SafetyCenterPage extends StatelessWidget { const SafetyCenterPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar:AppBar(title:const Text('Safety Center')),body:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Stay in control.',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:8),const Text('Block people you do not want to interact with, and report serious problems for review.',style:TextStyle(color:Colors.white54)),const SizedBox(height:20),
    Card(child:ListTile(leading:const Icon(Icons.block),title:const Text('Blocking'),subtitle:const Text('Blocked accounts should not be able to contact or discover you.'))),
    Card(child:ListTile(leading:const Icon(Icons.flag_outlined),title:const Text('Reporting'),subtitle:const Text('Report threats, coercion, hate, blackmail, targeted harassment, spam or other serious abuse.'))),
    Card(child:ListTile(leading:const Icon(Icons.lock_outline),title:const Text('Privacy'),subtitle:const Text('Keep your profile discoverable only when you want to be found.'))),
  ]));
}

class SafetyActionPage extends StatefulWidget { final String userId,userName; const SafetyActionPage({super.key,required this.userId,required this.userName}); @override State<SafetyActionPage> createState()=>_SafetyActionPageState(); }
class _SafetyActionPageState extends State<SafetyActionPage>{
  bool busy=false;
  Future<void> block() async { setState(()=>busy=true); try { await db.from('blocks').upsert({'blocker_id':db.auth.currentUser!.id,'blocked_id':widget.userId}); if(mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('User blocked'))); Navigator.pop(context); } } catch(e){ if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not block user: $e'))); } finally{if(mounted)setState(()=>busy=false);} }
  Future<void> report(String reason) async { setState(()=>busy=true); try { await db.from('reports').insert({'reporter_id':db.auth.currentUser!.id,'reported_user_id':widget.userId,'reason':reason,'status':'open'}); if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Report submitted')));Navigator.pop(context);} } catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not submit report: $e')));} finally{if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Safety')),body:ListView(padding:const EdgeInsets.all(18),children:[Text(widget.userName,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800)),const SizedBox(height:18),FilledButton.tonalIcon(onPressed:busy?null:block,icon:const Icon(Icons.block),label:const Text('Block this person')),const SizedBox(height:18),const Text('Report for',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),...['Threats or intimidation','Harassment or hate','Blackmail or coercion','Spam or scam','Other serious safety issue'].map((r)=>Card(child:ListTile(title:Text(r),trailing:const Icon(Icons.chevron_right),onTap:busy?null:()=>report(r))))]));
}

// Vibe 1.11: playable game experiences with server-authoritative XP submission and stable idempotency keys.
class QuizClashPage extends StatefulWidget { final String? sessionId; const QuizClashPage({super.key,this.sessionId}); @override State<QuizClashPage> createState()=>_QuizClashPageState(); }
class _QuizClashPageState extends State<QuizClashPage>{
  final qs=[
    ['Which planet is known as the Red Planet?',['Earth','Mars','Venus','Jupiter'],1],
    ['What is the largest ocean?',['Atlantic','Indian','Arctic','Pacific'],3],
    ['Which language runs Flutter apps?',['Dart','Swift','Kotlin','Java'],0],
    ['How many sides does a hexagon have?',['5','6','7','8'],1],
    ['Which one is a mammal?',['Shark','Dolphin','Trout','Tuna'],1],
  ];
  int i=0,score=0; bool done=false,busy=false; int opponentAnswers=0; RealtimeChannel? channel;
  String? roundId;
  @override void initState(){super.initState(); _prepareRound();}
  Future<void> _prepareRound() async {
    if(widget.sessionId==null)return;
    try{
      final r=await db.rpc('create_match_round',params:{'p_session_id':widget.sessionId,'p_round_no':i+1});
      roundId=r['id'].toString();
      channel ??= db.channel('quiz_${widget.sessionId}')
        ..onPostgresChanges(event:PostgresChangeEvent.insert,schema:'public',table:'game_answers',callback:(payload){
          final row=payload.newRecord;
          if(row['game_round_id']==roundId && row['user_id']!=db.auth.currentUser!.id && mounted)setState(()=>opponentAnswers++);
        })..subscribe();
    }catch(_){ }
  }
  Future<void> answer(int n) async {
    if(done||busy)return; busy=true;
    final correct=n==qs[i][2]; final nextScore=score+(correct?100:0);
    try{if(roundId!=null)await db.rpc('submit_game_answer',params:{'p_round_id':roundId,'p_answer_key':n.toString()});}catch(_){ }
    if(i==qs.length-1){
      score=nextScore; setState(()=>done=true);
      if(widget.sessionId!=null){try{await db.rpc('finish_game_match',params:{'p_session_id':widget.sessionId,'p_player_one_score':score,'p_player_two_score':score});}catch(_){}}
    }else{setState((){score=nextScore;i++;busy=false;opponentAnswers=0;roundId=null;}); await _prepareRound(); return;}
    busy=false;
  }
  @override void dispose(){if(channel!=null)db.removeChannel(channel!);super.dispose();}
  @override Widget build(BuildContext c){final q=qs[i]; return Scaffold(appBar:AppBar(title:const Text('Quiz Clash')),body:Padding(padding:const EdgeInsets.all(20),child:done?Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Text('Match complete',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('$score XP',style:const TextStyle(fontSize:26)),const SizedBox(height:8),Text('Your opponent answered $opponentAnswers round${opponentAnswers==1?'':'s'}',style:const TextStyle(color:Colors.white54)),const SizedBox(height:18),FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('Back to Play'))])):Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Question ${i+1}/${qs.length}',style:const TextStyle(color:Colors.white54)),const SizedBox(height:8),Text('Opponent progress  •  $opponentAnswers answer${opponentAnswers==1?'':'s'} received',style:const TextStyle(color:Colors.white54)),const SizedBox(height:16),Text(q[0] as String,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800)),const SizedBox(height:22),...(q[1] as List<String>).asMap().entries.map((e)=>Padding(padding:const EdgeInsets.only(bottom:12),child:SizedBox(width:double.infinity,height:54,child:FilledButton.tonal(onPressed:busy?null:()=>answer(e.key),child:Text(e.value))))),const Spacer(),Text('Score  $score',style:const TextStyle(fontWeight:FontWeight.bold))]));}
}

class ReactionRushPage extends StatefulWidget { final String? sessionId; const ReactionRushPage({super.key,this.sessionId}); @override State<ReactionRushPage> createState()=>_ReactionRushPageState(); }
class _ReactionRushPageState extends State<ReactionRushPage>{
  bool active=false,finished=false; int taps=0; DateTime? started;
  void start(){setState((){active=true;finished=false;taps=0;started=DateTime.now();}); Future.delayed(const Duration(seconds:5),(){if(mounted&&active)setState((){active=false;finished=true;}); if(widget.sessionId!=null){db.rpc('record_game_xp',params:{'p_session_id':widget.sessionId,'p_game_type':'reaction_rush','p_score':taps,'p_idempotency_key':'reaction-${widget.sessionId}'}).catchError((_){return 0;});}});}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Reaction Rush')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('REACTION RUSH',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,letterSpacing:2)),const SizedBox(height:8),Text(finished?'You scored $taps taps in 5 seconds':active?'TAP! TAP! TAP!':'Ready when you are',style:const TextStyle(color:Colors.white60)),const SizedBox(height:30),GestureDetector(onTap:active?()=>setState(()=>taps++):null,child:Container(width:190,height:190,decoration:BoxDecoration(shape:BoxShape.circle,gradient:LinearGradient(colors:active?[const Color(0xFF14B8A6),const Color(0xFF8B5CF6)]:[const Color(0xFF20232D),const Color(0xFF15171F)])),child:Center(child:Text(active?'TAP':'START',style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900))))),const SizedBox(height:26),if(!active)FilledButton(onPressed:start,child:Text(finished?'Play again':'Start'))]))));
}
